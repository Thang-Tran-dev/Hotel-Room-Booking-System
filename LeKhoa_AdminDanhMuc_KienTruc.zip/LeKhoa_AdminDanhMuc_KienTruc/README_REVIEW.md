# Người 6 – Admin: phòng, voucher, dịch vụ + lõi hệ thống & đối chiếu sơ đồ class

**Use case của bạn:** Manage room, Manage service, Manage voucher

Gói này chỉ chứa **các file bạn phải review** (đã xóa mọi file không liên quan). Để chạy được chương trình hãy dùng dự án đầy đủ `hotel.zip`, rồi mở các file dưới đây trong đó.

## File của bạn
| Loại | File | Nội dung |
|---|---|---|
| Môi trường | `README.md` | Hotel Booking – HTML + CSS + Python only (Flask + SQLite) |
| Liên kết | `app.py` | Application entry point. |
| Test | `controllers/__init__.py` |  |
| Python | `controllers/admin_catalog.py` | Admin: rooms (+ room types, image upload), vouchers, services. |
| Liên kết | `controllers/blueprints.py` | The three blueprints (groups of pages). Every controller file adds its pages to one of them. |
| Python | `controllers/helpers.py` | Small helpers shared by all controllers: login checks, image upload, QR code, template filters, error handling. |
| Tài liệu | `docs/OWNERSHIP.md` | Ai review file nào (HTML · CSS · Python · Môi trường · Liên kết) |
| Tài liệu | `docs/TASK_ASSIGNMENT.md` | Phân công Review & Testing cho 6 người (theo yêu cầu giảng viên) |
| Tài liệu | `docs/TRACEABILITY.md` | Traceability: Use case → Class diagram → Page → Test |
| Test | `models/__init__.py` |  |
| Liên kết | `models/actors/__init__.py` | Actors of the class diagram: Guest ◁ Customer, Guest ◁ Admin. Each actor is assembled from small mixins (one file per owner). |
| Python | `models/actors/admin_catalog.py` | Admin operations: manage rooms, room types, services, vouchers. |
| Python | `models/base.py` | Base classes: Entity (class-diagram objects) and Repository (generic SQL access). |
| Test | `services/__init__.py` |  |
| CSS | `static/css/base.css` | BASE: colours, layout helpers, navbar, buttons, forms, cards, tables, badges, flash messages |
| Test | `static/images/beach.jpg` |  |
| Test | `static/images/r1.jpg` |  |
| Test | `static/images/r2.jpg` |  |
| Test | `static/images/r3.jpg` |  |
| Test | `static/images/r4.jpg` |  |
| HTML | `templates/admin/rooms.html` |  |
| HTML | `templates/admin/services.html` |  |
| HTML | `templates/admin/vouchers.html` |  |
| HTML | `templates/base.html` | Hotel Booking |
| Test | `tests/conftest.py` |  |
| Test | `tests/helpers.py` | Small helpers shared by all test files (sign in as customer/admin, book a room, finish a stay, …). |
| Test | `tests/test_p6_admin_catalog.py` | Person 6 – Admin catalog: rooms, room types, services, vouchers, image upload + project rules.   Run:  pytest tests/test_p6_admin_catalog.py -v |

## Liên kết sang file của người khác (không có trong gói này)
- Bạn là người nối mọi phần: `app.py` import các controller của cả 5 người; `models/actors/__init__.py` ghép các mixin; `templates/base.html` nạp 6 file CSS
- `templates/admin/_layout.html` + `static/css/admin.css` (Người 5) dùng cho các trang danh mục của bạn

## Cách làm việc
1. Trong dự án đầy đủ: `pip install -r requirements.txt` rồi `python app.py` (http://localhost:5000).
2. Chạy test của bạn: `pytest tests/test_p6_*.py -v`.
3. Review theo luồng: template (HTML) → controller → actor → service → repository (SQL); đối chiếu use case ở `docs/TRACEABILITY.md`.
4. Mỗi lỗi tìm thấy: tạo GitHub Issue, sửa bằng Pull Request, chạy lại test.
5. Viết test case vào **Testing Document Template** của giảng viên (xem `docs/TASK_ASSIGNMENT.md`).
