# Ai review file nào (HTML · CSS · Python · Môi trường · Liên kết)

Mỗi file có **đúng một người phụ trách**. Danh sách này sinh từ cùng bảng dùng để tạo 6 gói trong `review_packages/`.

## Người 1 – Tài khoản & hồ sơ
**Use case:** Register account, Login, Logout, Reset password, Change password, Update profile

| Loại | File | Nội dung |
|---|---|---|
| Môi trường | `config.py` | Settings, helpers and the shared ApiError. |
| Python | `models/account.py` | Account entity + UserRepo (users table). |
| Python | `models/actors/guest_account.py` | Guest operations about accounts: sign up / sign in. |
| Python | `models/actors/customer_account.py` | Customer operations about the profile. |
| Python | `services/auth_service.py` | Use cases: register, sign in, reset / change password, profile. |
| Python | `controllers/auth.py` | Sign in, sign up, forgot password, logout. |
| Python | `controllers/account.py` | Customer profile and change password. |
| HTML | `templates/auth/_split.html` | Layout shared by login / signup / forgot: photo on the left, form on the right |
| HTML | `templates/auth/login.html` | Sign in |
| HTML | `templates/auth/signup.html` | Sign up |
| HTML | `templates/auth/forgot.html` | Forgot password |
| HTML | `templates/profile.html` | Profile |
| HTML | `templates/password.html` | Change password |
| CSS | `static/css/auth.css` | AUTH: sign in / sign up / forgot password / change password |
| Test | `tests/test_p1_accounts.py` | Person 1 – Accounts: register, login, logout, reset / change password, profile.   Run:  pytest tests/test_p1_accounts.py -v |

**Liên kết sang file của người khác:**
- `templates/base.html` – navbar có Sign in / Sign up / Logout (Người 6)
- `controllers/blueprints.py` + `controllers/helpers.py` – `guest_bp`, `customer_bp`, `require_login`, bắt lỗi `ApiError` (Người 6)
- `models/actors/__init__.py` ghép `Guest`/`Customer` (Người 6); `models/base.py` (`Entity`, `Repository`)
- `app.py` đăng ký controller của bạn (Người 6)

## Người 2 – Trang chủ, danh sách & chi tiết phòng
**Use case:** View room list, View room detail, Search room, Filter room

| Loại | File | Nội dung |
|---|---|---|
| Môi trường | `requirements.txt` | thư viện cần cài |
| Python | `models/room.py` | Room, RoomType, Service entities + their repositories. |
| Python | `models/actors/guest_rooms.py` | Guest operations about rooms: list, detail, search, filter. |
| Python | `services/room_service.py` | Room list, search / filter and room detail. |
| Python | `controllers/rooms.py` | Home page, room list and room detail. |
| HTML | `templates/home.html` |  |
| HTML | `templates/rooms.html` | Rooms |
| HTML | `templates/room_detail.html` | {{ room.code }} |
| CSS | `static/css/rooms.css` | ROOMS: home page, room list, room detail |
| Test | `tests/test_p2_rooms.py` | Person 2 – Rooms: list, detail, search, filter.   Run:  pytest tests/test_p2_rooms.py -v |

**Liên kết sang file của người khác:**
- `models/booking.py` – `BookingRepo.busy()` quyết định phòng còn trống (Người 3)
- `controllers/booking.py` – nút "Book now" gửi form tới `customer.start_booking` (Người 3)
- `controllers/my_bookings.py` – nút "Review this room" tới `customer.review` (Người 4)
- `templates/base.html`, `static/css/base.css` (Người 6)

## Người 3 – Đặt phòng, giá, thanh toán, hóa đơn
**Use case:** Book room, Apply voucher, Make payment, Pay online, Pay at hotel, Issue invoice

| Loại | File | Nội dung |
|---|---|---|
| Môi trường | `models/database.py` | Database connection, table creation / migration, sample data, and the (simulated) e-mail sender. |
| Python | `models/booking.py` | Booking, BookingDetail, Payment, Invoice, Voucher entities + their repositories. |
| Python | `models/actors/customer_booking.py` | Customer operations: choose a room, create a booking, apply voucher, pay. |
| Python | `services/pricing_service.py` | Price calculation: nights × price + services − vouchers + VAT, deposit 30 %. |
| Python | `services/booking_service.py` | Booking use cases: create a booking, pay, view. |
| Python | `controllers/booking.py` | Book a room: room page → booking summary (+ voucher) → confirm → payment → success. |
| HTML | `templates/booking.html` | Booking |
| HTML | `templates/payment.html` | Payment |
| HTML | `templates/success.html` | Payment successful |
| HTML | `templates/_macros.html` | Room summary card shown on the booking and payment pages |
| CSS | `static/css/booking.css` | BOOKING: booking summary, price lines, voucher, payment (QR / card), success |
| Test | `tests/test_p3_booking.py` | Person 3 – Booking and payment: book room, voucher, extra service price, pay, invoice.   Run:  pytest tests/test_p3_booking.py -v |

**Liên kết sang file của người khác:**
- `templates/room_detail.html` – form "Book now" (Người 2)
- `services/after_booking_service.py` – `BookingService` kế thừa mixin của Người 4; `services/admin_booking_service.py` – mixin của Người 5
- `models/mailer.py` – gửi hóa đơn (Người 4)
- `templates/my_bookings.html` – nút Pay dẫn tới `customer.pay` (Người 4)
- `models/base.py`, `controllers/helpers.py` (`qr_svg`), `templates/base.html` (Người 6)

## Người 4 – Booking của tôi, hủy + hoàn tiền, thêm dịch vụ, đánh giá
**Use case:** View my bookings, Cancel booking, Refund payment, Review stay, Add extra service

| Loại | File | Nội dung |
|---|---|---|
| Môi trường | `models/mailer.py` | Simulated e-mail sender: appends every message to emails.log. |
| Môi trường | `.gitignore` | file không đưa lên Git |
| Python | `models/review.py` | Review entity + ReviewRepo. |
| Python | `models/actors/customer_after_booking.py` | Customer operations after booking: history, cancel, review, add service. |
| Python | `services/after_booking_service.py` | Booking use cases after booking: cancel (+ refund), add service, review. |
| Python | `controllers/my_bookings.py` | My bookings, cancel (+ refund), add service, review. |
| HTML | `templates/my_bookings.html` | My bookings |
| HTML | `templates/cancel.html` | Cancel booking |
| HTML | `templates/add_service.html` | Add service |
| HTML | `templates/review.html` | Review |
| CSS | `static/css/after_booking.css` | AFTER BOOKING: cancel dialog, review form + CSS star rating |
| Test | `tests/test_p4_after_booking.py` | Person 4 – After booking: my bookings, cancel + refund, add service, review.   Run:  pytest tests/test_p4_after_booking.py -v |

**Liên kết sang file của người khác:**
- `models/booking.py` – `Payment.refund`, `Booking` (Người 3)
- `services/booking_service.py` – phần lõi (`_owned`, `dto`) mà mixin của bạn dùng (Người 3)
- `templates/room_detail.html` – liên kết sang trang review (Người 2)
- `controllers/helpers.py` (`save_image`), `static/css/base.css` (lớp `.sky`, `.star-on`) (Người 6)

## Người 5 – Admin: đặt phòng, check-in/out, doanh thu, khách hàng
**Use case:** Manage booking, Check-in, Check-out, Add incidental charge, View revenue, Manage user

| Loại | File | Nội dung |
|---|---|---|
| Môi trường | `wsgi.py` |  |
| Môi trường | `Procfile` | lệnh chạy gunicorn |
| Python | `models/actors/admin_operations.py` | Admin operations: bookings, check-in / check-out, charges, revenue, users. |
| Python | `services/admin_booking_service.py` | Admin use cases on bookings: approve / reject, check-in, check-out, charges, revenue, create customer. |
| Python | `controllers/admin_operations.py` | Admin: bookings, check-in / check-out / charges, revenue, users. |
| HTML | `templates/admin/_layout.html` | Layout shared by all admin pages: sidebar on the left, light-blue workspace on the right |
| HTML | `templates/admin/bookings.html` |  |
| HTML | `templates/admin/revenue.html` |  |
| HTML | `templates/admin/users.html` |  |
| HTML | `templates/admin/user_new.html` |  |
| CSS | `static/css/admin.css` | ADMIN: sidebar + light-blue work panel |
| Test | `tests/test_p5_admin_ops.py` | Person 5 – Admin operations: approve, check-in / out, charges, revenue, users.   Run:  pytest tests/test_p5_admin_ops.py -v |

**Liên kết sang file của người khác:**
- `templates/admin/_layout.html` (của bạn) được các trang của Người 6 dùng chung
- `services/booking_service.py`, `models/booking.py` – lõi và thực thể `Booking/Payment/Invoice` (Người 3)
- `templates/base.html` – mục "⚙ Management" ở navbar (Người 6)
- `controllers/admin_catalog.py` – cùng blueprint `admin_bp` (Người 6)

## Người 6 – Admin: phòng, voucher, dịch vụ + lõi hệ thống & đối chiếu sơ đồ class
**Use case:** Manage room, Manage service, Manage voucher

| Loại | File | Nội dung |
|---|---|---|
| Liên kết | `app.py` | Application entry point. |
| Môi trường | `README.md` | Hotel Booking – HTML + CSS + Python only (Flask + SQLite) |
| Python | `models/base.py` | Base classes: Entity (class-diagram objects) and Repository (generic SQL access). |
| Liên kết | `models/actors/__init__.py` | Actors of the class diagram: Guest ◁ Customer, Guest ◁ Admin. Each actor is assembled from small mixins (one file per owner). |
| Python | `models/actors/admin_catalog.py` | Admin operations: manage rooms, room types, services, vouchers. |
| Liên kết | `controllers/blueprints.py` | The three blueprints (groups of pages). Every controller file adds its pages to one of them. |
| Python | `controllers/helpers.py` | Small helpers shared by all controllers: login checks, image upload, QR code, template filters, error handling. |
| Python | `controllers/admin_catalog.py` | Admin: rooms (+ room types, image upload), vouchers, services. |
| HTML | `templates/base.html` | Hotel Booking |
| HTML | `templates/admin/rooms.html` |  |
| HTML | `templates/admin/vouchers.html` |  |
| HTML | `templates/admin/services.html` |  |
| CSS | `static/css/base.css` | BASE: colours, layout helpers, navbar, buttons, forms, cards, tables, badges, flash messages |
| Test | `tests/conftest.py` |  |
| Test | `tests/helpers.py` | Small helpers shared by all test files (sign in as customer/admin, book a room, finish a stay, …). |
| Test | `tests/test_p6_admin_catalog.py` | Person 6 – Admin catalog: rooms, room types, services, vouchers, image upload + project rules.   Run:  pytest tests/test_p6_admin_catalog.py -v |
| Tài liệu | `docs/TRACEABILITY.md` | Traceability: Use case → Class diagram → Page → Test |
| Tài liệu | `docs/TASK_ASSIGNMENT.md` | Phân công Review & Testing cho 6 người (theo yêu cầu giảng viên) |
| Tài liệu | `docs/OWNERSHIP.md` |  |
| Liên kết | `config.py` | Settings, helpers and the shared ApiError. |
| Liên kết | `__init__ files` |  |
| Python | các file `__init__.py` | khai báo package |
| Tài nguyên | `static/images/*` | ảnh phòng và ảnh nền |

**Liên kết sang file của người khác:**
- Bạn là người nối mọi phần: `app.py` import các controller của cả 5 người; `models/actors/__init__.py` ghép các mixin; `templates/base.html` nạp 6 file CSS
- `templates/admin/_layout.html` + `static/css/admin.css` (Người 5) dùng cho các trang danh mục của bạn
