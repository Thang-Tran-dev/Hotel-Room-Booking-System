# Traceability: Use case → Class diagram → Page → Test

Class diagram → code: `models/account.py`, `room.py`, `booking.py`, `review.py` (Account, Room, RoomType, Service, Voucher, Booking, BookingDetail, Payment, Invoice, Review) and `models/actors/` (Guest, Customer ◁ Guest, Admin ◁ Guest).
Every operation in the diagram exists with the same name (snake_case). Pages call them from `controllers/`; logic lives in `services/`; SQL in the repository classes inside `models/*.py`.

| Use case | Actor | Class.operation | Page (route → template) | Tests (`tests/test_p1…p6`) |
|---|---|---|---|---|
| Register account | Guest | `Guest.sign_up` | `/signup` → `auth/signup.html` | `test_register_*`, `test_signup_then_login` |
| Login | Guest | `Guest.sign_in` | `/login` → `auth/login.html` | `test_login_*`, `test_wrong_login_*` |
| Reset password | Guest | `Account.reset_password` | `/forgot` → `auth/forgot.html` | `test_reset_password_*` |
| View room list | Guest | `Guest.view_room_list` | `/rooms` → `rooms.html` | `test_view_room_list` |
| View room detail | Guest | `Guest.view_room_detail`, `Room.get_room_detail` | `/rooms/<code>` → `room_detail.html` | `test_view_room_detail*` |
| Search room | Guest | `Guest.search_room` | `/` search bar → `/rooms?q&cin&cout` | `test_search_room_by_keyword` |
| Filter room | Guest | `Guest.filter_room` | `/rooms` filter box | `test_filter_*` |
| Logout | Customer/Admin | `Account.logout` | navbar button (POST `/logout`) | `test_logout` |
| Change password | Customer/Admin | `Account.change_password`, `validate_password` | `/password` → `password.html` | `test_change_password_*` |
| Update profile | Customer | `Customer.view_profile`, `update_profile` | `/profile` → `profile.html` | `test_update_profile*` |
| Book room | Customer | `Customer.select_room`, `create_booking`, `Booking.calculate_total` | `/book/<code>` → `/booking` → `/booking/confirm` | `test_book_room_*`, `test_full_booking_flow_with_forms` |
| Apply voucher | Customer | `Customer.apply_voucher`, `Voucher.is_valid` | `/booking/voucher` (booking page) | `test_apply_voucher`, `test_book_with_voucher_discount` |
| Add extra service | Customer | `Customer.add_service` | room page dropdown; `/my/<code>/service` → `add_service.html` | `test_add_service_*` |
| Make payment | Customer | `Customer.pay`, `Payment.process` | `/pay/<code>` → `payment.html`, `/success/<code>` | `test_pay_*` |
| Pay online | Customer / Payment system | `Payment` (momo/bank → QR, card → form) | `/pay/<code>` | `test_pay_online_*`, `test_card_payment_needs_valid_details` |
| Pay at hotel | Customer | `Payment` (method `hotel`) | not offered on `/pay` – see "To confirm" | `test_pay_at_hotel_is_pending` |
| Issue invoice («include») | system | `Invoice.issue_invoice`, `send_email` | automatic (e-mail → `emails.log`) | `test_pay_online_*`, `test_admin_checkout_issues_invoice` |
| View my bookings | Customer | `Customer.view_booking_history` | `/my` → `my_bookings.html` | `test_view_my_bookings` |
| Cancel booking | Customer | `Customer.cancel_booking`, `Booking.update_status` | `/my/<code>/cancel` → `cancel.html` | `test_cancel_*` |
| Refund payment («extend») | Payment system | `Payment.refund` | automatic (cancel ≥ 24 h before check-in) | `test_cancel_paid_booking_refunds_payment` |
| Review stay | Customer | `Customer.write_review` | `/review/<room>` → `review.html` | `test_review_*` |
| Manage booking | Admin | `Admin.view_all_bookings`, `approve_booking` | `/admin/bookings` → `admin/bookings.html` | `test_admin_approve_booking` |
| Check-in / Check-out | Admin | `Admin.check_in`, `check_out` | `/admin/revenue` → `admin/revenue.html` | `test_admin_checkin_*`, `test_admin_checkout_issues_invoice` |
| Add incidental charge | Admin | `Admin.add_incidental_charge` | `/admin/revenue` | `test_admin_*charge*` |
| View revenue | Admin | `Admin.view_revenue` | `/admin/revenue` | `test_admin_view_revenue` |
| Manage room | Admin | `Admin.manage_room`, `manage_room_type` | `/admin/rooms` → `admin/rooms.html` (image upload from computer) | `test_admin_manage_room*`, `test_admin_can_upload_room_image_from_computer` |
| Manage service | Admin | `Admin.manage_service` | `/admin/services` | `test_admin_manage_service` |
| Manage voucher | Admin | `Admin.manage_voucher` | `/admin/vouchers` | `test_admin_voucher_*` |
| Manage user | Admin | `Admin.manage_user` | `/admin/users`, `/admin/users/new` | `test_admin_lock_*`, `test_admin_create_customer_with_booking` |

Language rule (spec): only **HTML + CSS + Python** – enforced by `test_project_uses_only_html_css_python` (no `.js` files, no `<script>`, no `onclick`).

## Database ↔ class diagram
`users` (Account + Customer/Admin) · `rooms` · `roomtypes` · `services` · `vouchers` · `bookings` · `booking_details` · `payments` · `invoices` · `reviews`. Old databases are upgraded automatically (`Database.migrate`).

## To confirm with the lecturer / team
1. **Pay at hotel** is a use case in the diagram, but the team asked for only two choices on the payment page (Momo/Bank, Credit/Debit). The back end supports it; one extra option in `payment.html` + `customer.pay` would enable it.
2. Booking–Voucher, Booking–Service and Room–Service relations are stored as comma-separated code lists instead of join tables.
3. The detailed use case specifications (main / alternative flows, messages) were not in the file received.
