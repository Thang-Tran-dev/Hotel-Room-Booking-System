# Phân công Review & Testing cho 6 người (theo yêu cầu giảng viên)

**Yêu cầu giảng viên → việc của nhóm**
1. Chương trình đủ chức năng, **OOP khớp sơ đồ class**, từng chức năng **khớp đặc tả use case** → mỗi người review phần mình + đối chiếu `docs/TRACEABILITY.md`.
2. **Test case phải viết đúng Testing Document Template** (Elearning 5, sai mẫu = 0 điểm) → chỉ Người 4 giữ file mẫu gốc; mọi người nhập vào bản sao, **không đổi tiêu đề cột**.
3. Áp dụng công cụ trong "Guidelines for group projects": **GitHub** (Người 1), **công cụ kiểm thử** pytest (Người 2), **Docker** (Người 3).

## Bảng phân công

| # | Người | Use case chịu trách nhiệm (30 UC) | Review code (danh sách file chính xác: `docs/OWNERSHIP.md`) | Test case | Công cụ / vai trò thêm |
|---|---|---|---|---|---|
| 1 | Tài khoản | Register account, Login, Logout, Reset password, Change password, Update profile | `auth/*`, `profile.html`, `password.html`, `auth.css`, `auth_service.py`, `Account`, `config.py` | TC101–… (≥ 24) | **GitHub**: tạo repo, nhánh `feature/<tên>`, mẫu Pull Request, Issues, bảo vệ nhánh `main` |
| 2 | Phòng | View room list, View room detail, Search room, Filter room | `home/rooms/room_detail.html`, `rooms.css`, `room_service.py`, `Room` | TC201–… (≥ 16) | **Công cụ test**: pytest + `pytest-cov`, báo cáo độ phủ, hướng dẫn chạy test |
| 3 | Đặt phòng & thanh toán | Book room, Apply voucher, Make payment, Pay online, Pay at hotel, Issue invoice | `booking/payment/success.html`, `pricing_service.py`, `booking_service.create/pay`, `Booking/Payment/Invoice/Voucher`, `database.py` | TC301–… (≥ 24) | **Docker**: `Dockerfile`, `docker-compose.yml`, chạy web + test trong container, volume cho `hotel.db` |
| 4 | Sau đặt phòng | View my bookings, Cancel booking, Refund payment, Review stay, Add extra service | `my_bookings/cancel/add_service/review.html`, `booking_service.cancel/add_service/review`, `Review`, `Mailer` | TC401–… (≥ 20) | **Tổng hợp tài liệu test**: gộp mọi test case vào **file mẫu gốc**, kiểm tra đúng cột, đánh số |
| 5 | Admin vận hành | Manage booking, Check-in, Check-out, Add incidental charge, View revenue, Manage user | `admin/_layout, bookings, revenue, users, user_new`, `admin.css`, `booking_service.admin_action/revenue`, `Admin` | TC501–… (≥ 24) | **Triển khai + minh chứng**: PythonAnywhere, ảnh chụp màn hình từng test GUI |
| 6 | Admin danh mục + kiến trúc | Manage room, Manage service, Manage voucher | `admin/rooms, vouchers, services`, `base.html/css`, `helpers.py`, `repositories.py`, `app.py` | TC601–… (≥ 12) | **Đối chiếu sơ đồ class**: kiểm 13 lớp (tên, thuộc tính, hàm) + báo cáo tổng kết |

Tổng ≥ 120 test case (mỗi use case ≥ 4: 1 đúng, ≥ 2 sai/ngoại lệ, 1 biên). Mỗi người **viết** test case của mình, còn **người ghép cặp thực hiện chạy**: 1↔2, 3↔4, 5↔6 (kiểm thử độc lập).

## Nội dung kiểm thử gợi ý theo từng người
- **1:** mật khẩu yếu / không khớp / email trùng; đăng nhập sai 4 lần → email cảnh báo trong `emails.log`; tài khoản bị khóa; đổi mật khẩu sai mật khẩu cũ; số điện thoại sai định dạng.
- **2:** giá = 0 là bỏ lọc; min > max; từ khóa gõ sai; lọc "Available"; phân trang 10 phòng/trang; mã phòng không tồn tại.
- **3:** ngày nhận trong quá khứ; trả phòng ≤ nhận phòng; vượt sức chứa; **hai trình duyệt cùng đặt một phòng** (409); voucher hết hạn/sai/vô hiệu; tính tiền: tiền phòng + dịch vụ − voucher + VAT 5%, cọc 30%; thẻ sai định dạng; hết hạn giữ phòng 15 phút; hóa đơn trong `emails.log`.
- **4:** hủy trước ≥ 24 h được hoàn cọc / hủy sát giờ không hoàn; hủy đặt phòng của người khác; thêm dịch vụ trùng; đánh giá chỉ sau khi trả phòng và chỉ một lần; ảnh đánh giá sai định dạng.
- **5:** duyệt / từ chối; nhận phòng sai CCCD; phụ phí âm hoặc thiếu lý do; trả phòng phát hành hóa đơn; tổng doanh thu; khóa / mở khóa; tạo khách kèm đặt phòng hộ (trả tại khách sạn, trùng lịch).
- **6:** thêm / sửa / xóa phòng; tải ảnh từ máy (file không phải ảnh, quá 5 MB); xóa phòng đang có đặt; loại phòng đang dùng; voucher % ngoài 1–100, ngày hết hạn trước ngày bắt đầu; vô hiệu / bật lại voucher; CRUD dịch vụ.

## Tiến độ (theo ngày làm việc, điều chỉnh theo hạn nộp)
| Ngày | Việc |
|---|---|
| 1 | Cả nhóm chạy được dự án (`README.md`), đọc sơ đồ class + use case. P1 dựng GitHub, P2 chạy `pytest -v`, P3 chạy Docker |
| 2–3 | Review code phần mình + review chéo phần **Liên kết** cặp (1↔2, 3↔4, 5↔6). Lỗi → **GitHub Issue** → sửa bằng Pull Request |
| 3–5 | Viết test case (mẫu của giảng viên) → ghép cặp chạy → ghi kết quả Pass/Fail + ảnh minh chứng. Lỗi mới → Issue → sửa → chạy lại |
| 6 | P4 gộp file test; P6 đối chiếu sơ đồ class + viết báo cáo; P5 kiểm tra bản triển khai |
| 7 | Rà soát cuối, luyện demo |

## Sản phẩm mỗi người nộp
1. Biên bản review (bảng: file – vấn đề – mức độ – đã sửa?) = danh sách GitHub Issues/PR của mình.
2. Test case của mình đã chạy xong, nhập vào bản sao **Testing Document Template**.
3. Minh chứng: ảnh chụp, kết quả `pytest`, lịch sử commit (mỗi người commit phần mình).
4. Phần công cụ phụ trách (xem cột cuối bảng): repo GitHub / báo cáo `pytest-cov` / Docker chạy được / file test tổng hợp / bản triển khai / bảng đối chiếu 13 lớp.

## Quy tắc chung
- Không đổi tiêu đề cột của file mẫu; mỗi test case có ID, chức năng, các bước, dữ liệu vào, kết quả mong đợi (và các cột còn lại nếu mẫu chính thức có).
- Test tự động (`tests/`) là bằng chứng bổ sung, **không thay** bảng test case theo mẫu.
- Mọi sửa code đi qua Pull Request, người ghép cặp duyệt trước khi gộp vào `main`.
